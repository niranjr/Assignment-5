/*********************************************************************************
*  WEB700 – Assignment 05
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part 
*  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name: Nirajbhai limbasiya Student ID:146215231  Date: 25/7/2024
*
********************************************************************************/ 

const express = require('express');
const path = require('path');
const collegeData = require('./collegeData');

const app = express();
const PORT = process.env.PORT || 8080;

const exphbs = require('express-handlebars');

app.get('/', (req, res) => {
    res.render('home');
});
app.engine('.hbs', exphbs.engine({ extname: '.hbs', defaultLayout: 'main' }));
app.set('view engine', '.hbs');
app.set('views', './views');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res, next) => {
    let route = req.path.substring(1);
    app.locals.activeRoute = '/' + (isNaN(route.split('/')[1]) ? route.replace(/\/(?!.*)/, '') : route.replace(/\/(.*)/, ''));
    next();
});
const hbs = exphbs.create({
    helpers: {
        navLink: function(url, options) {
            return '<li' +
                ((url == app.locals.activeRoute) ? ' class="nav-item active" ' : ' class="nav-item" ') +
                '><a class="nav-link" href="' + url + '">' + options.fn(this) + '</a></li>';
        },
        equal: function (lvalue, rvalue, options) {
            if (arguments.length < 3)
                throw new Error("Handlebars Helper equal needs 2 parameters");
            if (lvalue != rvalue) {
                return options.inverse(this);
            } else {
                return options.fn(this);
            }
        }
    }
});
app.engine('.hbs', hbs.engine);
app.get('/students', (req, res) => {
    collegeData.getAllStudents().then((data) => {
        res.render('students', { students: data });
    }).catch((err) => {
        res.render('students', { message: "no results" });
    });
});

app.get('/tas', (req, res) => {
    collegeData.getTAs()
        .then(tas => res.json(tas))
        .catch(err => res.json({ message: "no results" }));
});

app.get('/courses', (req, res) => {
    collegeData.getCourses()
        .then(courses => res.json(courses))
        .catch(err => res.json({ message: "no results" }));
});
app.get('/courses', (req, res) => {
    collegeData.getAllCourses().then((data) => {
        res.render('courses', { courses: data });
    }).catch((err) => {
        res.render('courses', { message: "no results" });
    });
});

app.get('/student/:num', (req, res) => {
    collegeData.getStudentByNum(req.params.num)
        .then(student => res.json(student))
        .catch(err => res.json({ message: "no results" }));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'home.html'));
});

app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'about.html'));
});

app.get('/htmlDemo', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'htmlDemo.html'));
});

app.get('/students/add', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'addStudent.html'));
});

app.post('/students/add', (req, res) => {
    collegeData.addStudent(req.body)
        .then(() => {
            res.redirect('/students');
        })
        .catch(err => {
            res.status(500).send("Error adding student");
        });
});

app.use((req, res) => {
    res.status(404).send('Page Not THERE');
});

collegeData.initialize().then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
}).catch((err) => {
    console.log(`Failed to initialize: ${err}`);
});
